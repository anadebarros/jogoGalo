# jogoGalo
Portuguese traditional game made with jQuery/Ajax requests using random.org API
